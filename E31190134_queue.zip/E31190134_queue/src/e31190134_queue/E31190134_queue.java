/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package e31190134_queue;
import java.util.*;

/**
 *
 * @author Isrolia
 */
public class E31190134_queue {

    public static void main(String[] args) {
        //menginisialisasi / menamakan interface queue menggunakan object linked list
        Queue<String> antrianUKT = new LinkedList<>();
        
        //menambahkan data atau nilai element baru ke list queue (Enqueue)
        antrianUKT.add("Nico");
        antrianUKT.add("Dimas");
        antrianUKT.add("Riki");
        antrianUKT.add("Isrolia");
        
        //menampilkan output hasil list
        System.out.println("Antrian Pembayaran UKT POLIJE : "+ antrianUKT);
        
        //menghapus element dari queue menggunakan operasi dequeue
        String nama = antrianUKT.remove();
        System.out.println("Menghapus Antrian : "+nama+ "|| Antrian Baru : "+antrianUKT);
        
        //menghapus element dengan method poll()
        nama = antrianUKT.poll();
        System.out.println("Menghapus Antrian : "+nama+"| Antrian Baru : "+antrianUKT);
        
    }
}
